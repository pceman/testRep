﻿#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration PrepSQLAO
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLServicecreds,

        [UInt32]$DatabaseEnginePort = 1433,
        
        [UInt32]$DatabaseMirrorPort = 5022,

        [Parameter(Mandatory)]
        [UInt32]$NumberOfDisks,

        [Parameter(Mandatory)]
        [String]$WorkloadType,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xComputerManagement,CDisk,xActiveDirectory,XDisk,xSql, xSQLServer, xSQLps,xNetworking
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServicecreds.UserName)", $SQLServicecreds.Password)

    $RebootVirtualMachine = $false

    if ($DomainName)
    {
        $RebootVirtualMachine = $true
    }

    #PCEMAN prepare disks
    #Get-WmiObject -Class Win32_volume -Filter "DriveLetter = 'e:'" |Set-WmiInstance -Arguments @{DriveLetter='B:'}
    #Get-Disk | where number -eq 2 | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "E" -UseMaximumSize | Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "ProdSQLData" -Confirm:$false -Force
    #Get-Disk | where number -eq 3 | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "F" -UseMaximumSize | Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "ProdSQLLogs" -Confirm:$false -Force
    #Get-Disk | where number -eq 4 | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "T" -UseMaximumSize | Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "ProdTempDB" -Confirm:$false -Force
    #Get-Disk | where number -eq 5 | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "G" -UseMaximumSize | Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "PilotSQLData" -Confirm:$false -Force
    #Get-Disk | where number -eq 6 | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "H" -UseMaximumSize | Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "PilotSQLLogs" -Confirm:$false -Force
    #Get-Disk | where number -eq 7 | Initialize-Disk -PartitionStyle GPT -PassThru | New-Partition -DriveLetter "O" -UseMaximumSize | Format-Volume -FileSystem NTFS -AllocationUnitSize 65536 -NewFileSystemLabel "SQLBackups" -Confirm:$false -Force

    #Finding the next avaiable disk letter for Add disk
    $NewDiskLetter = ls function:[f-z]: -n | ?{ !(test-path $_) } | select -First 1 
    $NextAvailableDiskLetter = $NewDiskLetter[0]
    
Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   1"

    WaitForSqlSetup

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   2"

    Node localhost
    {
        xSqlCreateVirtualDataDisk NewVirtualDisk
        {
            NumberOfDisks = $NumberOfDisks
            NumberOfColumns = $NumberOfDisks
            DiskLetter = $NextAvailableDiskLetter
            OptimizationType = $WorkloadType
            StartingDeviceID = 2
            RebootVirtualMachine = $RebootVirtualMachine
        }
    
    #PCEMAN
    #$global:DSCMachineStatus = 1

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   2.5"

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   3"

        WindowsFeature FailoverClusterTools 
        { 
            Ensure = "Present" 
            Name = "RSAT-Clustering-Mgmt"
            DependsOn = "[WindowsFeature]FC"
        } 

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   4"

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   5"

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   6"

        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
	        DependsOn = "[WindowsFeature]ADPS"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   7"        
        
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
	        DependsOn = "[xWaitForADDomain]DscForestWait"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   8"        

        xFirewall DatabaseEngineFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = $DatabaseEnginePort -as [String]
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   9"

        xFirewall DatabaseMirroringFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = $DatabaseMirrorPort -as [String]
            Ensure = "Present"
            DependsOn = "[xComputer]DomainJoin"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   10"

        xSqlLogin AddDomainAdminAccountToSysadminServerRole
        {
            Name = $DomainCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $Admincreds
            DependsOn = "[xComputer]DomainJoin"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   11"

        xADUser CreateSqlServerServiceAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SQLServicecreds.UserName
            Password = $SQLServicecreds
            Ensure = "Present"
            DependsOn = "[xSqlLogin]AddDomainAdminAccountToSysadminServerRole"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   12"

        xSqlLogin AddSqlServerServiceAccountToSysadminServerRole
        {
            Name = $SQLCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $Admincreds
            DependsOn = "[xADUser]CreateSqlServerServiceAccount"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   13"
        
        xSqlTsqlEndpoint AddSqlServerEndpoint
        {
            InstanceName = "MSSQLSERVER"
            PortNumber = $DatabaseEnginePort
            SqlAdministratorCredential = $Admincreds
            DependsOn = "[xSqlLogin]AddSqlServerServiceAccountToSysadminServerRole"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   14"

        xSQLServerStorageSettings AddSQLServerStorageSettings
        {
            InstanceName = "MSSQLSERVER"
            OptimizationType = $WorkloadType
            DependsOn = "[xSqlTsqlEndpoint]AddSqlServerEndpoint"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   15"        

        xSqlServer ConfigureSqlServerWithAlwaysOn
        {
            InstanceName = $env:COMPUTERNAME
            SqlAdministratorCredential = $Admincreds
            ServiceCredential = $SQLCreds
            MaxDegreeOfParallelism = 1
            FilePath = "E:\DATA"
            LogPath = "E:\LOG"
            DomainAdministratorCredential = $DomainFQDNCreds
            EnableTcpIp = $true
            DependsOn = "[xSqlLogin]AddSqlServerServiceAccountToSysadminServerRole"
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   16"

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

Out-File -FilePath C:\log.txt -Append -InputObject "$((Get-Date).ToString('hh:mm:ss')):   17"

    }
}
function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}
function WaitForSqlSetup
{
    # Wait for SQL Server Setup to finish before proceeding.
    while ($true)
    {
        try
        {
            Get-ScheduledTaskInfo "\ConfigureSqlImageTasks\RunConfigureImage" -ErrorAction Stop
            Start-Sleep -Seconds 5
        }
        catch
        {
            break
        }
    }
}
